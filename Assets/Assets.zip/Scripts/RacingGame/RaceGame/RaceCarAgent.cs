using Grpc.Core;
using System;
using System.Collections.Generic;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Sensors;
using UnityEngine;

public class RaceCarAgent : Agent
{

    [Header("Space Ship References")]
    private RaceCarControl _carControl;
    private RaceCarState _carState;

    [Header("Rewards")]
    [SerializeField] private float _winReward = 10.0f;
    [SerializeField] private float _loseReward = -10.0f;
    [SerializeField] private float _timeReward = 0.000f;
    [SerializeField] private float _wallHitReward = 0.000f;
    [SerializeField] private float _wallNotHitReward = 0.000f;
    [SerializeField] private float _speedReward = 0.000f;
    [SerializeField] private float _goingBackwardsReward = -0.5f;
    //[SerializeField] private float _timeReward = -0.005f;
    //[SerializeField] private float _wallHitReward = -1.0f;
    //[SerializeField] private float _wallNotHitReward = 2f;
    //[SerializeField] private float _speedReward = 0.001f;
    //[SerializeField] private float _goingBackwardsReward = -0.5f;

    [Header("Iterations")]
    [SerializeField] private int _maxIterations = 1000;
    [SerializeField] private int _currentIterations = 0;


    public override void OnEpisodeBegin()
    {
        _carState.ResetPoints();
        _currentIterations = 0;
        _carControl.resetPosition();
        //List<Vector2> positions = GenerateVariousPoints(5, 1.5f);
        //_shipControl.SetPosition(positions[0]);
    }



    public override void OnActionReceived(ActionBuffers actions)
    {
        AddReward(_timeReward);

        _currentIterations++;
        if (_currentIterations > _maxIterations)
        {
            FinishEpisode(false);
        }

        //int moveX = actions.DiscreteActions[0] - 1;
        //int moveZ = actions.DiscreteActions[1] - 1;
        float turn = actions.ContinuousActions[0];
        float throttle = actions.ContinuousActions[1];
        _carControl.Move(turn, throttle);

        Debug.Log(GetCumulativeReward()+" distanes: " + _carControl.distanceToWall()[0]+", "+ _carControl.distanceToWall()[1] + ", "+ _carControl.distanceToWall()[2] + ", " + "|"+_carControl.isGoingBackwards());
    }

    // Observations
    public override void CollectObservations(VectorSensor sensor)
    {
        // Space ship position [2]
        float[] sensorData = _carControl.distanceToWall();
        sensor.AddObservation(sensorData[0]);
        sensor.AddObservation(sensorData[1]);
        sensor.AddObservation(sensorData[2]);
        sensor.AddObservation(_carControl.getVelocity());
        sensor.AddObservation(_carControl.isGoingBackwards());

        // Current score [1]
        //sensor.AddObservation(_carState.NormalizedPoints);

        // 2 x Valid target [2] + 2 x Invalid target [2] 
        // [8] Observations
        //try
        //{
        //    sensor.AddObservation(_validTargets[0].NormalizedPosition);
        //    sensor.AddObservation(_validTargets[1].NormalizedPosition);

        //    sensor.AddObservation(_invalidTargets[0].NormalizedPosition);
        //    sensor.AddObservation(_invalidTargets[1].NormalizedPosition);
        //}
        //catch (IndexOutOfRangeException ex)
        //{
        //    Debug.LogError(ex.Message);
        //}
    }

    private void OnTriggerEnter(Collider other)
    {


        
        int finish = LayerMask.NameToLayer("Finish");

        if (other.gameObject.layer == finish) {
        Debug.Log("finisz");
            SetReward(_winReward);
            FinishEpisode(true);
        }
        
        //// Collect valid target
        //if (other.CompareTag()
        //{
        //    SetReward(_collectValidTargetPoints);
        //    validTarget.SetPosition(GenerateVariousPoints(1, 0.0f)[0]);
        //    _shipState.AddPoints(1);
        //}

        //// Collect invalid target
        //if (other.TryGetComponent<VirusTarget>(out VirusTarget invalidTarget))
        //{
        //    SetReward(_collectInvalidTargetPoints);
        //    invalidTarget.SetPosition(GenerateVariousPoints(1, 0.0f)[0]);
        //    _shipState.AddPoints(-1);
        //}
    }
    private void OnCollisionEnter(Collision collision)
    {
        int walls = LayerMask.NameToLayer("Walls");
        // Sprawdzamy, czy warstwa opuszczaj�cego obiektu zgadza si� z naszym ID
        if (collision.gameObject.layer == walls)
        {
            //AddReward(_wallHitReward);
            SetReward(_wallHitReward);
            FinishEpisode(false);
        }
        else
        {
            SetReward(_wallNotHitReward);
        }
    }
    private void FinishEpisode(bool wonEpisode)
    {
        _carState.ResetPoints();

        if (wonEpisode)
        {
            //_colorNotifier.OnEpisodeWon();
            AddReward(_winReward);
        }
        else
        {
            //_colorNotifier.OnEpisodeLost();
            AddReward(_loseReward);
        }

        //_labelDisplayer.DisplayRewards(GetCumulativeReward());
        EndEpisode();
    }
    public override void Heuristic(in ActionBuffers actionsOut)
    { }

















    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Start()
    {
        _carControl = GetComponent<RaceCarControl>();
        _carState = GetComponent<RaceCarState>();
    }

    // Update is called once per frame
    void Update()
    {
        if (_carState.CollectedPoints < 0)
        {
            FinishEpisode(false);
        }
        AddReward(_speedReward * _carControl.getVelocity());
        Debug.Log(_carControl.getVelocity());
        if (_carControl.isGoingBackwards()) AddReward(_goingBackwardsReward);
    }
}
